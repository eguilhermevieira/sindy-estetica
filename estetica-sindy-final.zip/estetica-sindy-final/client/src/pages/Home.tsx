import { ChevronLeft, ChevronRight, Menu, X } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [currentProcedure, setCurrentProcedure] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Only before/after results - no procedure photos
  const slides = [
    {
      image: "/WhatsAppImage2025-11-07at03.26.59.jpeg",
      title: "Modelagem Corporal",
      description: "Resultados incríveis com criolipólise e radiofrequência",
    },
    {
      image: "/WhatsAppImage2025-11-07at03.27.00.jpeg",
      title: "Redução de Gordura",
      description: "Transformação visível em poucas sessões",
    },
    {
      image: "/WhatsAppImage2025-11-07at03.27.00(1).jpeg",
      title: "Definição Corporal",
      description: "Corpo mais firme e tonificado",
    },
    {
      image: "/WhatsAppImage2025-11-07at03.27.00(2).jpeg",
      title: "Contorno Perfeito",
      description: "Silhueta mais harmonizada e elegante",
    },
    {
      image: "/WhatsAppImage2025-11-07at03.27.00(3).jpeg",
      title: "Rejuvenescimento",
      description: "Pele mais jovem e radiante",
    },
    {
      image: "/WhatsAppImage2025-11-07at03.27.00(4).jpeg",
      title: "Estética Facial",
      description: "Beleza natural e sofisticada",
    },
    {
      image: "/WhatsAppImage2025-11-07at03.27.00(5).jpeg",
      title: "Bem-Estar Total",
      description: "Saúde e autoestima em primeiro lugar",
    },
  ];

  const procedures = [
    {
      image: "/criolipolis-procedure.jpg",
      title: "Criolipólise",
      description: "Tecnologia avançada para redução de gordura localizada"
    },
    {
      image: "/radiofrequency-procedure.jpg",
      title: "Radiofrequência",
      description: "Rejuvenescimento e firmeza da pele com energia controlada"
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const nextProcedure = () => {
    setCurrentProcedure((prev) => (prev + 1) % procedures.length);
  };

  const prevProcedure = () => {
    setCurrentProcedure((prev) => (prev - 1 + procedures.length) % procedures.length);
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#F5F1ED" }}>
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-white bg-opacity-95 backdrop-blur-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14 sm:h-16 md:h-20">
            <div className="flex items-center">
              <img src="/logo.png" alt="Sindy Barrios" className="h-8 sm:h-10 md:h-12 w-auto" />
            </div>

            <div className="hidden md:flex items-center gap-8">
              <a href="#results" className="text-xs md:text-sm font-medium text-gray-700 hover:text-amber-600 transition">
                RESULTADOS
              </a>
              <a href="#procedures" className="text-xs md:text-sm font-medium text-gray-700 hover:text-amber-600 transition">
                PROCEDIMENTOS
              </a>
              <a href="#clinic" className="text-xs md:text-sm font-medium text-gray-700 hover:text-amber-600 transition">
                CLINICA
              </a>
              <a href="#about" className="text-xs md:text-sm font-medium text-gray-700 hover:text-amber-600 transition">
                SOBRE
              </a>
            </div>

            <button
              onClick={() => window.open("https://wa.me/", "_blank")}
              className="hidden md:block px-5 py-2 text-xs md:text-sm font-medium border border-gray-400 hover:border-amber-600 hover:text-amber-600 transition"
              style={{ color: "#2D2D2D" }}
            >
              AGENDE
            </button>

            <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>

          {mobileMenuOpen && (
            <div className="md:hidden pb-3 space-y-2">
              <a href="#results" className="block text-xs font-medium text-gray-700">
                RESULTADOS
              </a>
              <a href="#procedures" className="block text-xs font-medium text-gray-700">
                PROCEDIMENTOS
              </a>
              <a href="#clinic" className="block text-xs font-medium text-gray-700">
                CLINICA
              </a>
              <a href="#about" className="block text-xs font-medium text-gray-700">
                SOBRE
              </a>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section with Background Image */}
      <section 
        className="relative pt-14 sm:pt-16 md:pt-20 h-64 sm:h-72 md:h-96 flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: "url('/hero-bg.png')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* Gradient Overlay */}
        <div className="absolute inset-0 z-0" style={{
          background: "linear-gradient(135deg, rgba(0,0,0,0.5) 0%, rgba(212,175,55,0.3) 50%, rgba(0,0,0,0.4) 100%)"
        }}></div>

        {/* Logo Background Glow with Gradient Transparency */}
        <div className="absolute inset-0 z-0 flex items-center justify-center opacity-20">
          <div style={{
            background: "linear-gradient(180deg, rgba(212,175,55,0.3) 0%, rgba(212,175,55,0) 100%)"
          }}>
            <img src="/logo.png" alt="Logo Glow" className="h-24 sm:h-32 md:h-48 w-auto blur-md" />
          </div>
        </div>

        {/* Content */}
        <div className="relative z-10 text-center text-white px-3 sm:px-4 md:px-6 flex flex-col items-center justify-center h-full gap-2 sm:gap-3 md:gap-4">
          {/* Logo - No Background */}
          <div className="flex justify-center">
            <img src="/logo.png" alt="Sindy Barrios" className="h-10 sm:h-14 md:h-20 w-auto drop-shadow-lg" />
          </div>

          <h1
            className="text-xl sm:text-2xl md:text-4xl lg:text-5xl font-light leading-tight"
            style={{ fontFamily: "'Playfair Display', serif", textShadow: "0 4px 12px rgba(0,0,0,0.4)" }}
          >
            Transformação Corporal
          </h1>
          <p 
            className="text-xs sm:text-sm md:text-base lg:text-lg font-light max-w-sm sm:max-w-md md:max-w-lg"
            style={{ textShadow: "0 2px 8px rgba(0,0,0,0.3)" }}
          >
            Procedimentos não invasivos para sua saúde e bem-estar
          </p>

          <div className="flex flex-col xs:flex-row gap-2 sm:gap-3 md:gap-4 justify-center pt-1 sm:pt-2 md:pt-3">
            <button
              onClick={() => window.open("https://wa.me/", "_blank")}
              className="px-4 sm:px-5 md:px-7 py-1.5 sm:py-2 md:py-2.5 text-xs sm:text-sm md:text-base font-medium border border-white hover:bg-white hover:text-gray-900 transition backdrop-blur-sm whitespace-nowrap"
            >
              AGENDE
            </button>
            <a
              href="#results"
              className="px-4 sm:px-5 md:px-7 py-1.5 sm:py-2 md:py-2.5 text-xs sm:text-sm md:text-base font-medium border border-white hover:bg-white hover:text-gray-900 transition backdrop-blur-sm whitespace-nowrap"
            >
              VER RESULTADOS
            </a>
          </div>
        </div>
      </section>

            {/* Sindy Professional Section - Newspaper Style */}
      <section id="sindy" className="py-6 sm:py-8 md:py-10" style={{ backgroundColor: "#F5F1ED" }}>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 items-start">
            {/* Sindy Photo - Left Side */}
            <div className="flex justify-center sm:justify-start order-2 sm:order-1">
              <div className="relative w-full max-w-[200px] sm:max-w-xs md:max-w-sm">
                <div
                  style={{
                    borderRadius: "16px",
                    border: "3px solid #D4AF37",
                    overflow: "hidden",
                    boxShadow: "0 12px 30px rgba(212, 175, 55, 0.15)",
                    aspectRatio: "3/4"
                  }}
                >
                  <picture>
                    <source media="(max-width: 640px)" srcSet="/sindy-mobile.png" />
                    <img
                      src="/sindy-professional.png"
                      alt="Sindy Barrios"
                      className="w-full h-full object-cover"
                    />
                  </picture>
                </div>
              </div>
            </div>

            {/* Sindy Information - Right Side */}
            <div className="order-1 sm:order-2">
              <div className="text-left">
                <p className="text-xs font-medium tracking-widest mb-1" style={{ color: "#D4AF37" }}>
                  PROFISSIONAL
                </p>
                <h2
                  className="text-xl sm:text-2xl md:text-3xl font-light mb-1 leading-tight"
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    color: "#2D2D2D",
                  }}
                >
                  Sindy Barrios
                </h2>
                <p className="text-xs sm:text-sm text-gray-600 font-light mb-3" style={{ color: "#708D81" }}>
                  Cosmetóloga & Especialista em Estética Avançada
                </p>
                
                <p className="text-xs sm:text-sm text-gray-700 leading-relaxed font-light mb-3">
                  Com 10+ anos de experiência, Sindy é especialista em procedimentos estéticos inovadores. Dedicada a transformar vidas através de atendimento humanizado e resultados comprovados.
                </p>
                
                <div className="space-y-1.5 text-xs sm:text-sm text-gray-700 font-light">
                  <p>✓ Cosmetóloga Certificada</p>
                  <p>✓ Especialista em Criolipólise</p>
                  <p>✓ Especialista em Radiofrequência</p>
                  <p>✓ Atendimento Personalizado</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Results Carousel Section - Only Before/After */}
      <section id="results" className="py-8 sm:py-12 md:py-16 lg:py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-6 sm:mb-8 md:mb-10 lg:mb-12">
            <p className="text-xs sm:text-sm font-medium tracking-widest mb-2 md:mb-3" style={{ color: "#D4AF37" }}>
              TRANSFORMAÇÕES
            </p>
            <h2
              className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-light"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: "#2D2D2D",
              }}
            >
              Resultados Reais
            </h2>
          </div>

          {/* Carousel */}
          <div className="relative">
            <div 
              className="relative bg-gray-200 overflow-hidden"
              style={{ 
                borderRadius: "16px", 
                aspectRatio: "16/9",
                border: "6px sm:border-8 solid #D4AF37",
                boxShadow: "0 20px 60px rgba(212, 175, 55, 0.15)"
              }}
            >
              <img
                src={slides[currentSlide].image}
                alt={slides[currentSlide].title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Navigation Buttons */}
            <button
              onClick={prevSlide}
              className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 bg-white rounded-full p-1.5 sm:p-2 md:p-3 hover:bg-gray-100 transition shadow-lg z-10"
            >
              <ChevronLeft size={18} className="sm:w-5 sm:h-5 md:w-6 md:h-6" style={{ color: "#D4AF37" }} />
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 bg-white rounded-full p-1.5 sm:p-2 md:p-3 hover:bg-gray-100 transition shadow-lg z-10"
            >
              <ChevronRight size={18} className="sm:w-5 sm:h-5 md:w-6 md:h-6" style={{ color: "#D4AF37" }} />
            </button>

            {/* Slide Info */}
            <div className="text-center mt-4 sm:mt-6 md:mt-8">
              <h3
                className="text-base sm:text-lg md:text-xl lg:text-2xl font-light mb-1 sm:mb-2"
                style={{
                  fontFamily: "'Playfair Display', serif",
                  color: "#2D2D2D",
                }}
              >
                {slides[currentSlide].title}
              </h3>
              <p className="text-xs sm:text-sm md:text-base text-gray-600 mb-3 sm:mb-4 md:mb-6">
                {slides[currentSlide].description}
              </p>

              {/* Indicators */}
              <div className="flex justify-center gap-1.5 sm:gap-2 flex-wrap">
                {slides.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentSlide(idx)}
                    className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full transition"
                    style={{
                      backgroundColor: idx === currentSlide ? "#D4AF37" : "#C9A961",
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Procedures Section - Carousel on Mobile, Grid on Desktop */}
      <section id="procedures" className="py-8 sm:py-12 md:py-16 lg:py-20" style={{ backgroundColor: "#F5F1ED" }}>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-6 sm:mb-8 md:mb-10 lg:mb-12">
            <p className="text-xs sm:text-sm font-medium tracking-widest mb-2 md:mb-3" style={{ color: "#D4AF37" }}>
              PROCEDIMENTOS EM AÇÃO
            </p>
            <h2
              className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-light"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: "#2D2D2D",
              }}
            >
              Veja Nosso Trabalho
            </h2>
          </div>

          {/* Mobile Carousel */}
          <div className="md:hidden">
            <div className="relative">
              <div
                style={{
                  borderRadius: "20px",
                  border: "5px sm:border-6 solid #D4AF37",
                  overflow: "hidden",
                  boxShadow: "0 15px 40px rgba(212, 175, 55, 0.2)",
                  aspectRatio: "4/3"
                }}
              >
                <img 
                  src={procedures[currentProcedure].image} 
                  alt={procedures[currentProcedure].title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Navigation Buttons */}
              <button
                onClick={prevProcedure}
                className="absolute left-2 sm:left-3 top-1/2 -translate-y-1/2 bg-white rounded-full p-1.5 sm:p-2 hover:bg-gray-100 transition shadow-lg z-10"
              >
                <ChevronLeft size={16} className="sm:w-5 sm:h-5" style={{ color: "#D4AF37" }} />
              </button>
              <button
                onClick={nextProcedure}
                className="absolute right-2 sm:right-3 top-1/2 -translate-y-1/2 bg-white rounded-full p-1.5 sm:p-2 hover:bg-gray-100 transition shadow-lg z-10"
              >
                <ChevronRight size={16} className="sm:w-5 sm:h-5" style={{ color: "#D4AF37" }} />
              </button>
            </div>

            <div className="text-center mt-3 sm:mt-4">
              <h3
                className="text-base sm:text-lg font-light"
                style={{
                  fontFamily: "'Playfair Display', serif",
                  color: "#2D2D2D",
                }}
              >
                {procedures[currentProcedure].title}
              </h3>
              <p className="text-xs sm:text-sm text-gray-600 mt-1 sm:mt-2">
                {procedures[currentProcedure].description}
              </p>

              {/* Indicators */}
              <div className="flex justify-center gap-2 mt-3 sm:mt-4">
                {procedures.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentProcedure(idx)}
                    className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full transition"
                    style={{
                      backgroundColor: idx === currentProcedure ? "#D4AF37" : "#C9A961",
                    }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Desktop Grid */}
          <div className="hidden md:grid grid-cols-2 gap-6 md:gap-8">
            {procedures.map((procedure, idx) => (
              <div key={idx} className="text-center">
                <div
                  style={{
                    borderRadius: "24px",
                    border: "6px solid #D4AF37",
                    overflow: "hidden",
                    boxShadow: "0 15px 40px rgba(212, 175, 55, 0.2)",
                    aspectRatio: "4/3"
                  }}
                >
                  <img 
                    src={procedure.image} 
                    alt={procedure.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3
                  className="text-lg md:text-xl font-light mt-4"
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    color: "#2D2D2D",
                  }}
                >
                  {procedure.title}
                </h3>
                <p className="text-sm md:text-base text-gray-600 mt-2">
                  {procedure.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Clinic Section - Highlighting Comfort */}
      <section id="clinic" className="py-8 sm:py-12 md:py-16 lg:py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-6 sm:mb-8 md:mb-10 lg:mb-12">
            <p className="text-xs sm:text-sm font-medium tracking-widest mb-2 md:mb-3" style={{ color: "#D4AF37" }}>
              NOSSA CLINICA
            </p>
            <h2
              className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-light"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: "#2D2D2D",
              }}
            >
              Um Espaço de Conforto e Profissionalismo
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 items-center">
            {/* Clinic Image with Frame */}
            <div
              style={{
                borderRadius: "20px",
                border: "6px sm:border-8 solid #D4AF37",
                overflow: "hidden",
                boxShadow: "0 20px 60px rgba(212, 175, 55, 0.2)",
                aspectRatio: "4/3"
              }}
            >
              <img
                src="/clinic.jpg"
                alt="Nossa Clínica"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Clinic Description */}
            <div>
              <h3
                className="text-lg sm:text-xl md:text-2xl lg:text-3xl font-light mb-3 sm:mb-4"
                style={{
                  fontFamily: "'Playfair Display', serif",
                  color: "#2D2D2D",
                }}
              >
                Ambiente Acolhedor
              </h3>
              <p className="text-xs sm:text-sm md:text-base text-gray-700 mb-3 sm:mb-4 leading-relaxed font-light">
                Nossa clínica foi projetada para oferecer o máximo conforto e segurança. Com equipamentos de última geração, ambiente climatizado e uma equipe dedicada, garantimos uma experiência premium em cada visita.
              </p>
              <ul className="space-y-2 sm:space-y-3 text-xs sm:text-sm md:text-base text-gray-700 font-light">
                <li>✓ Equipamentos de última geração</li>
                <li>✓ Ambiente climatizado e acolhedor</li>
                <li>✓ Profissionais certificados</li>
                <li>✓ Higiene e segurança em primeiro lugar</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-8 sm:py-12 md:py-16 lg:py-20" style={{ backgroundColor: "#F5F1ED" }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-xs sm:text-sm font-medium tracking-widest mb-2 md:mb-3" style={{ color: "#D4AF37" }}>
              SOBRE SINDY
            </p>
            <h2
              className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-light mb-4 sm:mb-6 md:mb-8"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: "#2D2D2D",
              }}
            >
              Sua Transformação é Nossa Missão
            </h2>
            <p className="text-xs sm:text-sm md:text-base text-gray-700 leading-relaxed font-light">
              Sindy Barrios e uma cosmetologa dedicada a promover saude e autoestima feminina. Com procedimentos avancados e atendimento humanizado, cada cliente e tratada como um todo, considerando suas necessidades fisicas, emocionais e psicologicas.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-8 sm:py-12 md:py-16 lg:py-20 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2
            className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-light mb-3 sm:mb-4 md:mb-6"
            style={{
              fontFamily: "'Playfair Display', serif",
              color: "#2D2D2D",
            }}
          >
            Pronta Para Sua Transformação?
          </h2>
          <p className="text-xs sm:text-sm md:text-base text-gray-700 mb-4 sm:mb-6 md:mb-8 font-light">
            Agende sua avaliação gratuita e descubra como podemos ajudá-la
          </p>
          <button
            onClick={() => window.open("https://wa.me/", "_blank")}
            className="px-6 sm:px-8 md:px-10 py-2 sm:py-3 md:py-4 text-xs sm:text-sm md:text-base font-medium text-white transition hover:opacity-90"
            style={{ backgroundColor: "#D4AF37" }}
          >
            AGENDE AGORA
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-6 sm:py-8 md:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 md:gap-12 mb-4 sm:mb-6 md:mb-8">
            <div>
              <h3 className="font-light text-sm sm:text-base md:text-lg mb-2 md:mb-4" style={{ color: "#D4AF37" }}>
                SINDY BARRIOS
              </h3>
              <p className="text-xs sm:text-sm text-gray-400 font-light">
                Cosmetologia & Estetica Avancada
              </p>
            </div>
            <div>
              <h3 className="font-light text-sm sm:text-base md:text-lg mb-2 md:mb-4" style={{ color: "#D4AF37" }}>
                NAVEGAÇÃO
              </h3>
              <ul className="space-y-1 text-gray-400 font-light text-xs sm:text-sm">
                <li><a href="#results" className="hover:text-white transition">Resultados</a></li>
                <li><a href="#procedures" className="hover:text-white transition">Procedimentos</a></li>
                <li><a href="#clinic" className="hover:text-white transition">Clínica</a></li>
                <li><a href="#about" className="hover:text-white transition">Sobre</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-light text-sm sm:text-base md:text-lg mb-2 md:mb-4" style={{ color: "#D4AF37" }}>
                CONTATO
              </h3>
              <a href="https://wa.me/" className="text-xs sm:text-sm text-gray-400 hover:text-white transition font-light">
                WhatsApp
              </a>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-4 sm:pt-6 md:pt-8 text-center text-xs sm:text-sm text-gray-400 font-light">
            <p>&copy; 2025 Sindy Barrios. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
